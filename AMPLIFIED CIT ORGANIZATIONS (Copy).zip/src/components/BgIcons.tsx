import cogSingle from '@/imports/cogwheel single.png'
import hardware  from '@/imports/computer-hardware.png'
import pencil    from '@/imports/pencil (1).png'
import ruler     from '@/imports/ruler.png'

const WHITE = 'brightness(0) invert(1)'

type Item = { src: string; top: string; left?: string; right?: string; size: number; rotate: number; opacity: number }

const ITEMS: Item[] = [
  // Left column — 8 items evenly across 0–100%
  { src: cogSingle, top: '1%',   left: '0%',  size: 140, rotate: -10,  opacity: 0.22 },
  { src: pencil,    top: '15%',  left: '2%',  size: 85,  rotate: -50,  opacity: 0.20 },
  { src: ruler,     top: '29%',  left: '0%',  size: 105, rotate: -30,  opacity: 0.18 },
  { src: hardware,  top: '43%',  left: '1%',  size: 140, rotate: 6,    opacity: 0.18 },
  { src: cogSingle, top: '57%',  left: '3%',  size: 75,  rotate: 34,   opacity: 0.20 },
  { src: pencil,    top: '70%',  left: '0%',  size: 90,  rotate: 45,   opacity: 0.18 },
  { src: cogSingle, top: '82%',  left: '5%',  size: 65,  rotate: -15,  opacity: 0.19 },
  { src: ruler,     top: '92%',  left: '0%',  size: 120, rotate: 5,    opacity: 0.17 },
  // Right column — 8 items evenly across 0–100%
  { src: hardware,  top: '1%',   right: '0%', size: 135, rotate: -8,   opacity: 0.18 },
  { src: cogSingle, top: '15%',  right: '1%', size: 145, rotate: 15,   opacity: 0.21 },
  { src: ruler,     top: '29%',  right: '2%', size: 100, rotate: 120,  opacity: 0.18 },
  { src: cogSingle, top: '43%',  right: '1%', size: 105, rotate: 22,   opacity: 0.20 },
  { src: pencil,    top: '57%',  right: '3%', size: 83,  rotate: 130,  opacity: 0.19 },
  { src: hardware,  top: '70%',  right: '0%', size: 138, rotate: -6,   opacity: 0.18 },
  { src: cogSingle, top: '82%',  right: '2%', size: 68,  rotate: -40,  opacity: 0.19 },
  { src: pencil,    top: '92%',  right: '4%', size: 87,  rotate: -130, opacity: 0.18 },
]

export default function BgIcons({ position = 'absolute' }: { position?: 'absolute' | 'fixed' }) {
  return (
    <div aria-hidden="true" style={{ position, inset: 0, pointerEvents: 'none', overflow: 'hidden', zIndex: 1 }}>
      {ITEMS.map((item, i) => (
        <img
          key={i}
          src={item.src}
          alt=""
          style={{
            position: 'absolute',
            top: item.top,
            left: item.left,
            right: item.right,
            width: item.size,
            height: item.size,
            objectFit: 'contain',
            opacity: item.opacity,
            transform: `rotate(${item.rotate}deg)`,
            filter: WHITE,
            mixBlendMode: 'screen',
          }}
        />
      ))}
    </div>
  )
}
