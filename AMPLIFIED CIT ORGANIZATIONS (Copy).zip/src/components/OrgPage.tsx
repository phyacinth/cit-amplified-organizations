import { useNavigate } from 'react-router'
import { useEffect, useRef, useState } from 'react'
import SiteFooter from './SiteFooter'
import BgIcons from './BgIcons'
import skyline from '@/imports/vecteezy_modern-cityscape-skyline_27992218.png'

// ── PALETTE ────────────────────────────────────────────────────────────
const P = {
  bg:        '#111844',
  bgMid:     '#1A2260',
  primary:   '#111844',
  secondary: '#4B5694',
  cream:     '#EAE0CF',
  gold:      '#E3A419',
  cardBg:    'linear-gradient(145deg, #1E2868 0%, #111844 100%)',
  border:    '#4B569444',
}

// ── TYPES ──────────────────────────────────────────────────────────────

export interface OrgAccomplishment {
  img: string | null
  label: string
  description: string
}

export interface OrgPerformance {
  img: string | null
  description: string
}

export interface OrgPubmat {
  img: string | null
  description: string
}

export interface OrgPartner {
  img: string | null
  name: string
  description: string
  url: string
}

export interface OrgPageData {
  logo: string
  name: string
  about: string
  fbUrl?: string
  accomplishments?: OrgAccomplishment[]
  performances?: OrgPerformance[]
  pubmats?: OrgPubmat[]
  partners?: OrgPartner[]
}

// ── HELPERS ────────────────────────────────────────────────────────────

function ImgSlot({ src, alt, label, fit = 'cover', height = 180 }: {
  src: string | null; alt: string; label: string; fit?: 'cover' | 'contain'; height?: number
}) {
  if (src) {
    return (
      <img
        src={src} alt={alt}
        style={{ width: '100%', height, objectFit: fit, display: 'block', borderRadius: 6 }}
      />
    )
  }
  return (
    <div style={{
      width: '100%', height,
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      background: `linear-gradient(135deg, ${P.primary} 0%, #1E2868 100%)`,
      border: `1px dashed ${P.secondary}55`,
      borderRadius: 6,
    }}>
      <span style={{ fontFamily: "'Orbitron', monospace", fontWeight: 700, fontSize: '10px', color: P.gold, marginBottom: 4 }}>
        [ IMG ]
      </span>
      <span style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: '8px', color: `${P.secondary}88`, letterSpacing: '0.2em', textTransform: 'uppercase' }}>
        {label}
      </span>
    </div>
  )
}

function SectionHeading({ children }: { children: React.ReactNode }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 28 }}>
      <div style={{ flex: 1, height: 1, background: `linear-gradient(90deg, transparent, ${P.gold}66)` }} />
      <h2 style={{
        fontFamily: "'Orbitron', monospace", fontWeight: 700,
        fontSize: 'clamp(0.85rem, 2vw, 1.15rem)', color: P.gold,
        letterSpacing: '0.1em', textTransform: 'uppercase',
        textShadow: `0 0 20px ${P.gold}66`, whiteSpace: 'nowrap', margin: 0,
      }}>
        {children}
      </h2>
      <div style={{ flex: 1, height: 1, background: `linear-gradient(90deg, ${P.gold}66, transparent)` }} />
    </div>
  )
}

function Card({ children }: { children: React.ReactNode }) {
  const [hov, setHov] = useState(false)
  return (
    <div
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        background: P.cardBg,
        border: `1px solid ${P.border}`,
        borderLeft: `1px solid ${hov ? P.gold : P.border}`,
        borderRadius: 6,
        boxShadow: '0 8px 24px rgba(0,0,0,0.35), 0 2px 6px rgba(0,0,0,0.25)',
        padding: 24,
        transition: 'border-left-color 0.25s',
      }}
    >
      {children}
    </div>
  )
}

const rowStyle: React.CSSProperties = {
  display: 'flex', flexDirection: 'row', gap: 24, flexWrap: 'wrap',
  background: 'linear-gradient(145deg, #1E2868 0%, #111844 100%)',
  border: `1px solid #4B569444`,
  borderRadius: 6,
  boxShadow: '0 8px 24px rgba(0,0,0,0.35), 0 2px 6px rgba(0,0,0,0.25)',
  padding: 20,
  overflow: 'hidden',
}

function AccomplishmentCard({ item }: { item: OrgAccomplishment }) {
  const [hov, setHov] = useState(false)
  return (
    <div
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{ ...rowStyle, borderLeft: `1px solid ${hov ? P.gold : '#4B569444'}`, transition: 'border-left-color 0.25s' }}
    >
      <div style={{ flexShrink: 0, width: 200 }}>
        <ImgSlot src={item.img} alt={item.label} label={item.label} fit="cover" height={160} />
      </div>
      <div style={{ flex: 1, minWidth: 200, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 10 }}>
        <p style={{ fontFamily: "'Orbitron', monospace", fontSize: '10px', color: P.gold, letterSpacing: '0.16em', textTransform: 'uppercase', margin: 0 }}>
          {item.label}
        </p>
        <p style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: '13px', color: P.cream, lineHeight: 1.85, margin: 0 }}>
          {item.description}
        </p>
      </div>
    </div>
  )
}

function PerformanceCard({ item, index }: { item: OrgPerformance; index: number }) {
  return (
    <div style={rowStyle}>
      <div style={{ flexShrink: 0, width: 200 }}>
        <ImgSlot src={item.img} alt={`Performance ${index + 1}`} label={`PERFORMANCE ${index + 1}`} fit="cover" height={160} />
      </div>
      <div style={{ flex: 1, minWidth: 200, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 10 }}>
        <p style={{ fontFamily: "'Orbitron', monospace", fontSize: '10px', color: P.gold, letterSpacing: '0.16em', textTransform: 'uppercase', margin: 0 }}>
          Performance {String(index + 1).padStart(2, '0')}
        </p>
        <p style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: '13px', color: P.cream, lineHeight: 1.85, margin: 0 }}>
          {item.description}
        </p>
      </div>
    </div>
  )
}

function PartnerCard({ partner }: { partner: OrgPartner }) {
  return (
    <a
      href={partner.url}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={`Visit ${partner.name}`}
      style={{
        flex: '1 1 200px', maxWidth: 280, textDecoration: 'none',
        display: 'flex', flexDirection: 'column', overflow: 'hidden',
        background: P.cardBg,
        border: `1px solid ${P.border}`,
        borderRadius: 6,
        boxShadow: '0 8px 24px rgba(0,0,0,0.35), 0 2px 6px rgba(0,0,0,0.25)',
        transition: 'border-color 0.3s, box-shadow 0.3s, transform 0.25s',
      }}
      onMouseEnter={e => {
        const el = e.currentTarget as HTMLElement
        el.style.borderColor = P.gold
        el.style.boxShadow = `0 12px 32px rgba(0,0,0,0.5), 0 0 20px ${P.gold}44`
        el.style.transform = 'translateY(-3px)'
      }}
      onMouseLeave={e => {
        const el = e.currentTarget as HTMLElement
        el.style.borderColor = P.border
        el.style.boxShadow = '0 8px 24px rgba(0,0,0,0.35), 0 2px 6px rgba(0,0,0,0.25)'
        el.style.transform = 'translateY(0)'
      }}
    >
      <div style={{ background: P.primary, borderRadius: '6px 6px 0 0', overflow: 'hidden' }}>
        <ImgSlot src={partner.img} alt={partner.name} label="PARTNER" fit="contain" height={110} />
      </div>
      <div style={{ padding: '14px 16px', borderTop: `1px solid ${P.secondary}33`, display: 'flex', flexDirection: 'column', gap: 8 }}>
        <p style={{ fontFamily: "'Orbitron', monospace", fontSize: '10px', color: P.gold, letterSpacing: '0.08em', textTransform: 'uppercase', margin: 0 }}>
          {partner.name}
        </p>
        <p style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: '11px', color: `${P.cream}AA`, lineHeight: 1.7, margin: 0 }}>
          {partner.description}
        </p>
        <span style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: '9px', color: `${P.secondary}99`, letterSpacing: '0.15em' }}>
          ▶ VISIT →
        </span>
      </div>
    </a>
  )
}

// ── ORG PAGE ──────────────────────────────────────────────────────────

export default function OrgPage({ data }: { data: OrgPageData }) {
  const navigate = useNavigate()

  const [scrolled, setScrolled] = useState(false)
  const [logoHovered, setLogoHovered] = useState(false)
  const heroRef = useRef<HTMLDivElement>(null)
  const { logo, name, about, fbUrl, accomplishments, performances, pubmats, partners } = data

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 100)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <div style={{ minHeight: '100vh', background: `linear-gradient(160deg, ${P.primary} 0%, ${P.bgMid} 50%, ${P.primary} 100%)` }}>

      {/* Decorative side icons */}
      <BgIcons position="fixed" />

      {/* Seamless grid fading into dark gradient */}
      <div className="fixed inset-0 pointer-events-none" aria-hidden="true" style={{
        backgroundImage: `linear-gradient(${P.secondary}28 1px, transparent 1px), linear-gradient(90deg, ${P.secondary}28 1px, transparent 1px)`,
        backgroundSize: '48px 48px',
        maskImage: 'radial-gradient(ellipse 80% 80% at 50% 40%, black 20%, transparent 100%)',
        WebkitMaskImage: 'radial-gradient(ellipse 80% 80% at 50% 40%, black 20%, transparent 100%)',
      }} />

      {/* Nav — becomes sticky header with org name on scroll */}
      <div style={{
        position: 'sticky', top: 0, zIndex: 50,
        padding: '14px 24px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        background: scrolled ? `${P.primary}EE` : 'transparent',
        backdropFilter: scrolled ? 'blur(12px)' : 'none',
        WebkitBackdropFilter: scrolled ? 'blur(12px)' : 'none',
        borderBottom: `1px solid ${scrolled ? P.secondary + '44' : P.secondary + '22'}`,
        transition: 'background 0.35s, border-color 0.35s, backdrop-filter 0.35s',
      }}>
        <button
          onClick={() => navigate('/')}
          style={{
            fontFamily: "'Share Tech Mono', monospace", fontSize: '12px',
            color: P.secondary,
            letterSpacing: '0.18em', textTransform: 'uppercase',
            background: 'none', border: 'none', cursor: 'pointer', transition: 'color 0.2s',
            fontWeight: 600,
          }}
          onMouseEnter={e => { (e.currentTarget as HTMLElement).style.color = P.cream }}
          onMouseLeave={e => { (e.currentTarget as HTMLElement).style.color = P.secondary }}
        >
          ◀ BACK TO NETWORK
        </button>

        {/* Org name fades in when scrolled */}
        <span style={{
          fontFamily: "'Orbitron', monospace", fontWeight: 700,
          fontSize: 'clamp(0.7rem, 2vw, 0.95rem)',
          color: P.gold, letterSpacing: '0.1em', textTransform: 'uppercase',
          textShadow: `0 0 16px ${P.gold}66`,
          opacity: scrolled ? 1 : 0,
          transform: scrolled ? 'translateY(0)' : 'translateY(-6px)',
          transition: 'opacity 0.35s, transform 0.35s',
          pointerEvents: 'none',
        }}>
          {name}
        </span>

        <span style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: '10px', color: `${P.secondary}55`, letterSpacing: '0.2em', textTransform: 'uppercase', opacity: scrolled ? 0 : 1, transition: 'opacity 0.35s' }}>
          ◆ CIT ORGANIZATION
        </span>
      </div>

      <div style={{ position: 'relative', zIndex: 10, maxWidth: 900, margin: '0 auto', padding: '0 24px 80px' }}>

        {/* Hero */}
        <header ref={heroRef} style={{ position: 'relative', display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', padding: '56px 0 48px', overflow: 'hidden' }}>

          {/* Skyline silhouette — anchored at bottom of hero, scrolls away with content */}
          <img
            src={skyline}
            alt=""
            aria-hidden="true"
            style={{
              position: 'absolute', bottom: 0,
              left: '50%', transform: 'translateX(-50%)',
              width: '100vw',
              height: '55%',
              objectFit: 'cover', objectPosition: 'bottom',
              opacity: 0.2,
              filter: 'invert(1)',
              mixBlendMode: 'screen',
              pointerEvents: 'none',
              userSelect: 'none',
            }}
          />
          <a
            href={fbUrl}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={`Visit ${name} on Facebook`}
            style={{ textDecoration: 'none', display: 'inline-block', marginBottom: 24 }}
            onMouseEnter={() => setLogoHovered(true)}
            onMouseLeave={() => setLogoHovered(false)}
          >
            <div
              style={{
                width: 150, height: 150,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                position: 'relative', overflow: 'hidden',
                background: P.cardBg,
                border: `1px solid ${P.gold}`,
                borderRadius: 6,
                boxShadow: logoHovered
                  ? `0 16px 48px rgba(0,0,0,0.65), 0 0 60px ${P.gold}66`
                  : `0 12px 36px rgba(0,0,0,0.5), 0 0 40px ${P.gold}33`,
                transform: logoHovered ? 'scale(1.1)' : 'scale(1)',
                transition: 'transform 0.3s ease, box-shadow 0.3s ease',
                cursor: fbUrl ? 'pointer' : 'default',
              }}
            >
              <img
                src={logo} alt={name}
                style={{ width: 120, height: 120, objectFit: 'contain', borderRadius: 6, filter: `drop-shadow(0 0 12px ${P.gold}55)` }}
              />
              <div style={{
                position: 'absolute', inset: 0,
                background: `linear-gradient(105deg, transparent 35%, ${P.gold}20 50%, transparent 65%)`,
                backgroundSize: '200% 100%',
                animation: 'card-shimmer 1.4s ease infinite',
                borderRadius: 6,
                opacity: logoHovered ? 1 : 0,
                transition: 'opacity 0.4s',
                pointerEvents: 'none',
              }} />
            </div>
          </a>

          <p style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: '11px', color: `${P.secondary}99`, letterSpacing: '0.3em', marginBottom: 8 }}>
            ◆ CIT ORGANIZATION ◆
          </p>
          <h1 style={{ fontFamily: "'Orbitron', monospace", fontWeight: 900, fontSize: 'clamp(2rem, 6vw, 3.6rem)', color: P.gold, letterSpacing: '0.06em', lineHeight: 1, textShadow: `0 0 40px ${P.gold}99, 0 2px 0 ${P.primary}`, margin: 0 }}>
            {name}
          </h1>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginTop: 20 }}>
            <div style={{ width: 60, height: 1, background: `linear-gradient(90deg, transparent, ${P.gold}66)` }} />
            <span style={{ color: `${P.gold}66`, fontSize: '8px', fontFamily: 'Share Tech Mono', letterSpacing: '0.2em' }}>◆◆◆</span>
            <div style={{ width: 60, height: 1, background: `linear-gradient(90deg, ${P.gold}66, transparent)` }} />
          </div>
        </header>

        {/* About */}
        <section style={{ marginBottom: 56 }}>
          <SectionHeading>About</SectionHeading>
          <Card>
            <p style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: '14px', color: P.cream, lineHeight: 1.9, margin: 0 }}>
              {about}
            </p>
          </Card>
        </section>

        {accomplishments && accomplishments.length > 0 && (
          <section style={{ marginBottom: 56 }}>
            <SectionHeading>Accomplishments</SectionHeading>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
              {accomplishments.map(a => <AccomplishmentCard key={a.label} item={a} />)}
            </div>
          </section>
        )}

        {performances && performances.length > 0 && (
          <section style={{ marginBottom: 56 }}>
            <SectionHeading>Performances</SectionHeading>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
              {performances.map((p, i) => <PerformanceCard key={i} item={p} index={i} />)}
            </div>
          </section>
        )}

        {pubmats && pubmats.length > 0 && (
          <section style={{ marginBottom: 56 }}>
            <SectionHeading>Publications</SectionHeading>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
              {pubmats.map((pub, i) => (
                <div key={i} style={rowStyle}>
                  <div style={{ flexShrink: 0, width: 200 }}>
                    <ImgSlot src={pub.img} alt={`Publication ${i + 1}`} label="PUBMAT" fit="cover" height={160} />
                  </div>
                  <div style={{ flex: 1, minWidth: 200, display: 'flex', alignItems: 'center' }}>
                    <p style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: '13px', color: P.cream, lineHeight: 1.85, margin: 0 }}>
                      {pub.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {partners && partners.length > 0 && (
          <section style={{ marginBottom: 32 }}>
            <SectionHeading>Partners</SectionHeading>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 20 }}>
              {partners.map(p => <PartnerCard key={p.name} partner={p} />)}
            </div>
          </section>
        )}
      </div>

      <SiteFooter />
    </div>
  )
}
