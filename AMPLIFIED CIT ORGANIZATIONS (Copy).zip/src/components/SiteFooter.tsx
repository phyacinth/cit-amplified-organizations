export interface OrgContact {
  facebook?: string
  email?: string
  phone?: string
  other?: string
}

const P = {
  bg:        '#111844',
  bgDeep:    '#0C1230',
  secondary: '#4B5694',
  cream:     '#EAE0CF',
  gold:      '#E3A419',
  border:    '#4B569433',
}

const ORGS = [
  { name: 'SPICE',  url: 'https://www.facebook.com/BulSUSpice' },
  { name: 'CREATIV',url: 'https://www.facebook.com/CITCreativ' },
  { name: 'INFINIX',url: 'https://www.facebook.com/profile.php?id=100088069686070' },
  { name: 'BAND',   url: 'https://www.facebook.com/band.cit' },
  { name: 'FFTS',   url: 'https://www.facebook.com/bulsucitffts' },
  { name: 'TEECS',  url: 'https://www.facebook.com/CIT.TEECS' },
  { name: 'SMTS',   url: 'https://www.facebook.com/profile.php?id=61570113532192' },
  { name: 'AATS',   url: 'https://www.facebook.com/cit.aats2022' },
  { name: 'CADS',   url: 'https://www.facebook.com/CADSOfficialpage' },
  { name: 'FUFAS',  url: 'https://www.facebook.com/FutureFabricatorsSociety' },
]

export default function SiteFooter() {
  return (
    <footer style={{
      background: P.bgDeep,
      borderTop: `1px solid ${P.border}`,
    }}>
      <div style={{
        maxWidth: 1100,
        margin: '0 auto',
        padding: '48px 40px 32px',
        display: 'flex',
        gap: 64,
        flexWrap: 'wrap',
        justifyContent: 'space-between',
      }}>

        {/* Left — BulSU CIT */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12, minWidth: 220 }}>
          <a
            href="https://www.facebook.com/bulsuCIT"
            target="_blank"
            rel="noopener noreferrer"
            style={{ textDecoration: 'none' }}
          >
            <span style={{
              fontFamily: "'Orbitron', monospace", fontWeight: 700,
              fontSize: '13px', color: P.gold,
              letterSpacing: '0.1em', textTransform: 'uppercase',
              display: 'block', marginBottom: 6,
            }}>
              BulSU — CIT
            </span>
            <span style={{
              fontFamily: "'Share Tech Mono', monospace", fontSize: '11px',
              color: `${P.secondary}BB`, letterSpacing: '0.12em', display: 'block',
            }}>
              College of Industrial Technology
            </span>
            <span style={{
              fontFamily: "'Share Tech Mono', monospace", fontSize: '10px',
              color: `${P.secondary}77`, letterSpacing: '0.14em', marginTop: 4, display: 'block',
            }}>
              facebook.com/bulsuCIT ↗
            </span>
          </a>

          <div style={{ marginTop: 16, height: 1, width: 48, background: `${P.gold}44` }} />
          <span style={{
            fontFamily: "'Share Tech Mono', monospace", fontSize: '9px',
            color: `${P.secondary}55`, letterSpacing: '0.2em', textTransform: 'uppercase',
          }}>
            Amplified CIT Network
          </span>
        </div>

        {/* Right — org links */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <span style={{
            fontFamily: "'Orbitron', monospace", fontWeight: 700,
            fontSize: '10px', color: `${P.cream}66`,
            letterSpacing: '0.16em', textTransform: 'uppercase', marginBottom: 4,
          }}>
            CIT Organizations
          </span>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(5, 1fr)',
            gap: '10px 32px',
          }}>
            {ORGS.map(org => (
              <a
                key={org.name}
                href={org.url}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  fontFamily: "'Share Tech Mono', monospace",
                  fontSize: '11px',
                  color: `${P.secondary}CC`,
                  letterSpacing: '0.1em',
                  textDecoration: 'none',
                  transition: 'color 0.2s',
                  whiteSpace: 'nowrap',
                }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.color = P.gold }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.color = `${P.secondary}CC` }}
              >
                {org.name}
              </a>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div style={{
        borderTop: `1px solid ${P.border}`,
        padding: '12px 40px',
        display: 'flex',
        justifyContent: 'center',
      }}>
        <span style={{
          fontFamily: "'Share Tech Mono', monospace", fontSize: '9px',
          color: `${P.secondary}44`, letterSpacing: '0.2em', textTransform: 'uppercase',
        }}>
          ◆ Bulacan State University — College of Industrial Technology ◆
        </span>
      </div>
    </footer>
  )
}
