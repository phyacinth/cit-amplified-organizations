import OrgPage, { OrgPageData } from '@/components/OrgPage'
import logo     from '@/imports/CIT AATS.jpg'
import partner1 from '@/imports/Partner1 AATS.png'

const data: OrgPageData = {
  logo,
  fbUrl: 'https://www.facebook.com/cit.aats2022',
  name: 'CIT AATS',
  about: 'Association of Automotive Technology Students.',
  partners: [
    {
      img: partner1,
      name: 'Hiroshima Hino Motors Co., Ltd.',
      description:
        'We also extend our heartfelt gratitude to Hiroshima Hino Motors Co., Ltd. and all our esteemed international industry partners for their unwavering trust, collaboration, and commitment to opening meaningful global opportunities for our graduates. Your continued support empowers our students and alumni to thrive in the international automotive industry.',
      url: 'https://www.bing.com/search?pglt=43&q=Hiroshima+Hino+Motors+Co.%2C+Ltd.',
    },
  ],
}

export default function AatsPage() {
  return <OrgPage data={data} />
}
