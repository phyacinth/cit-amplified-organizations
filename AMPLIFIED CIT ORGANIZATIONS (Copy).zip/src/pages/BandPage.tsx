import OrgPage, { OrgPageData } from '@/components/OrgPage'
import logo    from '@/imports/CIT BAND.jpg'
import award1  from '@/imports/AWARD 1 CIT BAND.jpg'
import award2  from '@/imports/AWARD 2 CIT BAND.jpg'
import award3  from '@/imports/AWARD 3 CIT BAND.jpg'
import perf1a  from '@/imports/PERFORMANCE 1 CIT BAND.jpg'
import perf1b  from '@/imports/PERFORMANCE 1 CIT BAND(1).jpg'
import perf2   from '@/imports/PERFORMANCE 2 CIT BAND.jpg'

const data: OrgPageData = {
  logo,
  fbUrl: 'https://www.facebook.com/band.cit',
  name: 'CIT BAND',
  about: 'We promote music as a powerful medium to reach everyone\'s heart and age.',
  accomplishments: [
    {
      img: award1,
      label: 'Award 01',
      description:
        "It's been an honor making music with you, and we know the music doesn't stop here. Thank you for being part of CIT BAND. Until the next note, we're with you.",
    },
    {
      img: award2,
      label: 'Award 02',
      description:
        "It's been an honor making music with you, and we know the music doesn't stop here. Thank you for being part of CIT BAND. Until the next note, we're with you.",
    },
    {
      img: award3,
      label: 'Award 03',
      description:
        'Congratulations!! to QUEE PASAA for securing 4th runner up during the Battle of the Bands organized by the Bulacan State University Committee on Student Groups and the BULSU Student Government on Friday, December 5, at the BulSU Heroes Park.',
    },
  ],
  performances: [
    {
      img: perf1a,
      description:
        'Day 2 of SAIL Academy \'26 will come alive with Chasing the Apex: Racing Toward Purpose-Driven Leadership as »»» CIT Band »»» takes the stage. Their performance will set the rhythm and build the energy, fueling the momentum as leaders prepare to take on the next defining turn.',
    },
    {
      img: perf1b,
      description: "CIT BAND @ CITFA's Year End Party 11 - 25 - 2025.",
    },
    {
      img: perf2,
      description:
        'CIT BAND @ Shaping Your Tech Career: A Student Road Map (CIT-CADS\'s Event).',
    },
  ],
}

export default function BandPage() {
  return <OrgPage data={data} />
}
