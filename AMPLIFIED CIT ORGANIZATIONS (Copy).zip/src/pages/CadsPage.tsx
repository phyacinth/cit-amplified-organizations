import OrgPage, { OrgPageData } from '@/components/OrgPage'
import logo     from '@/imports/CIT CADS.jpg'
import partner1 from '@/imports/PARTNER 1 CADS.jpg'
import partner2 from '@/imports/partner 2 cads.jpg'

const data: OrgPageData = {
  logo,
  fbUrl: 'https://www.facebook.com/CADSOfficialpage',
  name: 'CIT CADS',
  about:
    'College Association of Drafting Students, BulSU-College of Industrial Technology.',
  partners: [
    {
      img: partner1,
      name: 'Inhinyero Maniniyot',
      description:
        "Follow me for more shots and don't forget to tag Inhinyerong Maniniyot if you'll use my shots, thanks! If you want to partner up or need my services, just send a message through the page! I'm happy to be the photographer in your events.",
      url: 'https://www.facebook.com/inhinyerongmaniniyot',
    },
    {
      img: partner2,
      name: 'Asya Design Partner',
      description:
        'CAD DETAILER (ARCHITECT TECHNOLOGY & ENGINEERING TECHNOLOGY) from Asya Design Partner.',
      url: 'https://www.bing.com/ck/a?!&&p=5469607eca6b2b65cf7f5709d079591679fb51c0862bfd89cf642e76d25129fbJmltdHM9MTc4NjA2MDgwMA&ptn=3&ver=2&hsh=4&fclid=12ac5a4a-a5ac-69ae-1f99-4d51a49768d5&psq=asya+design&u=a1aHR0cHM6Ly95aGMzbHhHVnphV2R1TG1OdmJTNXdhQzg',
    },
  ],
}

export default function CadsPage() {
  return <OrgPage data={data} />
}
