import OrgPage, { OrgPageData } from '@/components/OrgPage'
import logo       from '@/imports/CIT CREATIV.jpg'
import award1     from '@/imports/AWARD 1 CREATIV.jpg'
import award2     from '@/imports/AWARD 2 CREATIVE.jpg'
import award3     from '@/imports/AWARD 3 CREATIV.jpg'
import partner1   from '@/imports/PARTNER 1 CREATIV.jpg'
import partner2   from '@/imports/PARTNER 2 CREATIV.jpg'
import partner3   from '@/imports/PARTNER 3 CREATIV.jpg'

const data: OrgPageData = {
  logo,
  fbUrl: 'https://www.facebook.com/CITCreativ',
  name: 'CIT CREATIV',
  about:
    'With every turn of the gears, we are reminded of the strength that comes from unity, innovation, and vision. This year, CIT-CREATIV (Collegiate Resource Auxiliary of Technological Visionaries) proudly upholds its mission of empowering students to lead with purpose, integrity, and creativity.',
  accomplishments: [
    {
      img: award1,
      label: 'Award 01',
      description:
        "CIT CREATIV emerges triumphant at OSOA QUEST - Baybayin: Sabay Sabay na Paglalakbay ng Balangay, claiming the prestigious award for 'Leadership Development.'",
    },
    {
      img: award2,
      label: 'Award 02',
      description:
        'Balangayan sa Unibersidad: SINAGLAYAG – Pagtahak sa Agos Tungo sa Mas Matatag na Paglalaya. Overall Top Grosser | PAGODA, Top Grosser: Service Category | PAGODA, Outstanding Student Organization.',
    },
    {
      img: award3,
      label: 'Award 03',
      description:
        "This year's journey has been a blend of beauty and challenge. Witnessing our officers' unwavering dedication to organizing every event and our active members' voluntary commitment to help us. We extend our heartfelt gratitude to each one of you; your tireless efforts have truly paid off. It is with immense joy that we announce our receipt of the \"TOP 5 AMONG 92 STUDENT ORGANIZATIONS\" award.",
    },
  ],
  partners: [
    {
      img: partner1,
      name: 'Buzzar',
      description: 'Bloom It Yourself "Crafting Vision, Inspiring Innovation"',
      url: 'https://www.facebook.com',
    },
    {
      img: partner2,
      name: 'Art More',
      description:
        'CIT CREATIV has officially partnered with ArtMore, securing exclusive benefits for our Classified Members.',
      url: 'https://www.facebook.com/ArtMoreLaserPrintPH',
    },
    {
      img: partner3,
      name: 'Donut Park - Garden Cafe Alido Malolos Branch',
      description:
        "We're thrilled to announce our official partnership with Donut Park - Garden Cafe Alido Malolos Branch, securing exclusive benefits for our Classified Members.",
      url: 'https://www.facebook.com/profile.php?id=61559295535185',
    },
  ],
}

export default function CreativPage() {
  return <OrgPage data={data} />
}
