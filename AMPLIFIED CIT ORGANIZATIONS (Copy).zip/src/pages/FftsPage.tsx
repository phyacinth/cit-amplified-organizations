import OrgPage, { OrgPageData } from '@/components/OrgPage'
import logo     from '@/imports/CIT FFTS.jpg'
import award1   from '@/imports/AWARD 1 FFTS.jpg'
import partner1 from '@/imports/PARTNER 1 FFTS.jpg'
import partner2 from '@/imports/PARTNER 2 FFTS.jpg'

const data: OrgPageData = {
  logo,
  fbUrl: 'https://www.facebook.com/bulsucitffts',
  name: 'CIT FFTS',
  about: 'FEDERATION OF FOOD TECHNOLOGY STUDENT "Connecting Passions, Uniting Ambitions"',
  accomplishments: [
    {
      img: award1,
      label: 'Award 01',
      description:
        'DAUNGAN BALANGAYAN 202 — Awards and recognitions from various activities of Balangayan in University 2022. 34 recognized student organizations gathered in Valencia Hall, Bulacan State University (BulSU) grounds for Daungan. Recognition Awards Night, November 14.',
    },
    {
      img: award1,
      label: 'Sanko Gakuen Partnership',
      description:
        'Special thanks to our partners, Sanko Gakuen and Interskills Development Foundation Inc., for making this possible.',
    },
  ],
  partners: [
    {
      img: partner1,
      name: 'Hult Prize',
      description:
        'We would also like to give a special shout-out to our amazing partner, Hult Prize BulSU, for joining hands with us in this meaningful collaboration. Your teamwork, creativity, and shared commitment to service truly made our booth stand out and our mission stronger.',
      url: 'https://www.facebook.com/hultprize',
    },
    {
      img: partner2,
      name: 'Partner',
      description: 'CIT FFTS valued partner.',
      url: 'https://www.facebook.com',
    },
  ],
}

export default function FftsPage() {
  return <OrgPage data={data} />
}
