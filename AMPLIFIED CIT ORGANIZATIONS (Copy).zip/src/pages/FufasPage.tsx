import OrgPage, { OrgPageData } from '@/components/OrgPage'
import logo   from '@/imports/CIT FUFAS.jpg'
import pubmat from '@/imports/Pubmat FUFAS.jpg'

const data: OrgPageData = {
  logo,
  fbUrl: 'https://www.facebook.com/FutureFabricatorsSociety',
  name: 'CIT FUFAS',
  about: 'FUTURE FABRICATION SOCIETY (FUFAS)',
  pubmats: [
    {
      img: pubmat,
      description:
        'Attention all Incoming Interns (OJT) CITizens! Details for the much-awaited preliminary OJT Orientation seminar will be posted soon! | Stay tuned! | Pubmats and Technicals: Robert F. Anzures Jr. | CIT - AATS',
    },
  ],
}

export default function FufasPage() {
  return <OrgPage data={data} />
}
