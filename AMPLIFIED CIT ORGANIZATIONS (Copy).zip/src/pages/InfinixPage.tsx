import OrgPage, { OrgPageData } from '@/components/OrgPage'
import logo       from '@/imports/CIT INFINIX.jpg'
import award1     from '@/imports/AWARD 1 INFINIX.jpg'
import perf1      from '@/imports/PERFORMANCE 1 INFINIX.jpg'

const data: OrgPageData = {
  logo,
  fbUrl: 'https://www.facebook.com/profile.php?id=100088069686070',
  name: 'CIT INFINIX',
  about: 'CIT INFINIX is a dance group under the College of Industrial Technology.',
  accomplishments: [
    {
      img: award1,
      label: 'Award 01',
      description:
        'With their passion, dedication, and hardwork, the CIT-INFINIX burned the dance floor at Angara Cup 2025 Hip-Hop Competition. They secured the title of being second-runner up!',
    },
  ],
  performances: [
    {
      img: perf1,
      description:
        'CIT-INFINIX had a successful performance in the recent "ANGARA-PSC-FAU Sportsfest 2023" Hip Hop Dance Competition category.',
    },
  ],
}

export default function InfinixPage() {
  return <OrgPage data={data} />
}
