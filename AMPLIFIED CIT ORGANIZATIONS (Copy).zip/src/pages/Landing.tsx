import { useRef, useEffect, useCallback, useState } from 'react'
import { useNavigate } from 'react-router'
import SiteFooter from '@/components/SiteFooter'
import BgIcons from '@/components/BgIcons'
import smtsLogo    from '@/imports/CIT SMTS.jpg'
import aatsLogo    from '@/imports/CIT AATS.jpg'
import bandLogo    from '@/imports/CIT BAND.jpg'
import cadsLogo    from '@/imports/CIT CADS.jpg'
import creativLogo from '@/imports/CIT CREATIV.jpg'
import fftsLogo    from '@/imports/CIT FFTS.jpg'
import fufasLogo   from '@/imports/CIT FUFAS.jpg'
import infinixLogo from '@/imports/CIT INFINIX.jpg'
import spiceLogo   from '@/imports/cit_spice.jpg'
import teecsLogo   from '@/imports/CIT TEECS.jpg'

// ── PALETTE ────────────────────────────────────────────────────────────
const P = {
  bg:        '#111844',
  bgMid:     '#1A2260',
  primary:   '#111844',
  secondary: '#4B5694',
  cream:     '#EAE0CF',
  gold:      '#E3A419',
  cardBg:    'linear-gradient(145deg, #1E2868 0%, #111844 100%)',
  border:    '#4B569444',
  borderHov: '#E3A419',
}

const ORGANIZATIONS = [
  { id: 1,  name: 'SMTS',    logo: smtsLogo,    url: '/smts'    },
  { id: 2,  name: 'AATS',    logo: aatsLogo,    url: '/aats'    },
  { id: 3,  name: 'BAND',    logo: bandLogo,    url: '/band'    },
  { id: 4,  name: 'CADS',    logo: cadsLogo,    url: '/cads'    },
  { id: 5,  name: 'CREATIV', logo: creativLogo, url: '/creativ' },
  { id: 6,  name: 'FFTS',    logo: fftsLogo,    url: '/ffts'    },
  { id: 7,  name: 'FUFAS',   logo: fufasLogo,   url: '/fufas'   },
  { id: 8,  name: 'INFINIX', logo: infinixLogo, url: '/infinix' },
  { id: 9,  name: 'SPICE',   logo: spiceLogo,   url: '/spice'   },
  { id: 10, name: 'TEECSS',  logo: teecsLogo,   url: '/teecs'   },
]

const CARD_W     = 220
const HALF       = CARD_W * ORGANIZATIONS.length
const BASE_SPEED = 0.65

function LogoCard({ org, onClick }: {
  org: typeof ORGANIZATIONS[number]
  onClick: (url: string) => void
}) {
  return (
    <button
      onClick={() => onClick(org.url)}
      aria-label={`Open ${org.name}`}
      className="group flex-shrink-0 flex flex-col items-center"
      style={{ width: 180, margin: '0 20px', background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}
    >
      <div
        className="w-full flex items-center justify-center overflow-hidden relative"
        style={{
          height: 160,
          background: P.cardBg,
          border: `1px solid ${P.border}`,
          borderRadius: 6,
          boxShadow: '0 8px 24px rgba(0,0,0,0.45), 0 2px 6px rgba(0,0,0,0.3)',
          transition: 'border-color 0.3s, box-shadow 0.3s',
        }}
        onMouseEnter={e => {
          const el = e.currentTarget as HTMLElement
          el.style.borderColor = P.gold
          el.style.boxShadow = `0 12px 32px rgba(0,0,0,0.55), 0 0 20px ${P.gold}44`
        }}
        onMouseLeave={e => {
          const el = e.currentTarget as HTMLElement
          el.style.borderColor = P.border
          el.style.boxShadow = '0 8px 24px rgba(0,0,0,0.45), 0 2px 6px rgba(0,0,0,0.3)'
        }}
      >
        {/* Logo image — same border radius as container */}
        <img
          src={org.logo} alt={org.name}
          className="transition-transform duration-300 group-hover:scale-110"
          style={{
            maxWidth: 120, maxHeight: 110, objectFit: 'contain',
            borderRadius: 6,
            filter: 'drop-shadow(0 2px 6px rgba(0,0,0,0.4))',
          }}
        />
        <div className="absolute inset-0 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-500"
          style={{
            background: `linear-gradient(105deg, transparent 35%, ${P.gold}18 50%, transparent 65%)`,
            backgroundSize: '200% 100%',
            animation: 'card-shimmer 1.4s ease infinite',
            borderRadius: 6,
          }} />
      </div>

      <p className="mt-2 text-center transition-all duration-300 group-hover:scale-105" style={{
        fontFamily: "'Orbitron', monospace", fontSize: '9px', fontWeight: 700,
        color: P.gold, letterSpacing: '0.08em', textTransform: 'uppercase', lineHeight: 1.4,
        textShadow: `0 0 8px ${P.gold}66`,
      }}>
        {org.name}
      </p>
    </button>
  )
}

export default function Landing() {
  const navigate        = useNavigate()
  const [titleHov, setTitleHov] = useState(false)
  const trackRef     = useRef<HTMLDivElement>(null)
  const posRef       = useRef(0)
  const pausedRef    = useRef(false)
  const rafRef       = useRef<number>(0)
  const frameRef     = useRef(0)
  const scrollbarRef = useRef<HTMLInputElement>(null)

  const pause  = useCallback(() => { pausedRef.current = true  }, [])
  const resume = useCallback(() => { pausedRef.current = false }, [])

  useEffect(() => {
    const tick = () => {
      if (!pausedRef.current && trackRef.current) {
        posRef.current -= BASE_SPEED
        if (posRef.current <= -HALF) posRef.current += HALF
        trackRef.current.style.transform = `translateX(${posRef.current}px)`
        frameRef.current++
        if (frameRef.current % 3 === 0 && scrollbarRef.current) {
          scrollbarRef.current.value = String((Math.abs(posRef.current) / HALF) * 100)
        }
      }
      rafRef.current = requestAnimationFrame(tick)
    }
    rafRef.current = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(rafRef.current)
  }, [])

  const onScrollbarInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const pct = parseFloat(e.target.value) / 100
    posRef.current = -(pct * HALF)
    if (trackRef.current) {
      trackRef.current.style.transform = `translateX(${posRef.current}px)`
    }
  }, [])

  const track = [...ORGANIZATIONS, ...ORGANIZATIONS]

  return (
    <div className="relative flex flex-col overflow-hidden"
      style={{ background: `linear-gradient(160deg, ${P.primary} 0%, ${P.bgMid} 50%, ${P.primary} 100%)` }}>

      {/* Seamless grid that fades into the background gradient */}
      <div className="absolute inset-0 pointer-events-none" aria-hidden="true" style={{
        backgroundImage: `linear-gradient(${P.secondary}30 1px, transparent 1px), linear-gradient(90deg, ${P.secondary}30 1px, transparent 1px)`,
        backgroundSize: '48px 48px',
        maskImage: 'radial-gradient(ellipse 85% 85% at 50% 50%, black 30%, transparent 100%)',
        WebkitMaskImage: 'radial-gradient(ellipse 85% 85% at 50% 50%, black 30%, transparent 100%)',
      }} />

      {/* Wire accent lines */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden" aria-hidden="true">
        <svg viewBox="0 0 1200 120" preserveAspectRatio="none"
          className="absolute bottom-0 left-0 w-full h-24 opacity-15">
          <path d="M0,60 Q200,20 400,60 T800,60 T1200,60" stroke={P.secondary} strokeWidth="1" fill="none"
            strokeDasharray="8 4" style={{ animation: 'wire-flow 4s linear infinite' }} />
          {[150, 350, 600, 850, 1050].map((x) => (
            <circle key={x} cx={x} cy={60} r={3} fill={P.gold} opacity={0.5} />
          ))}
        </svg>
        <svg viewBox="0 0 1200 120" preserveAspectRatio="none"
          className="absolute top-0 left-0 w-full h-24 opacity-15 rotate-180">
          <path d="M0,60 Q300,30 600,60 T1200,60" stroke={P.secondary} strokeWidth="1" fill="none"
            strokeDasharray="6 8" style={{ animation: 'wire-flow 6s linear infinite reverse' }} />
        </svg>
      </div>

      {/* Main viewport section — vertically centered, footer sits below */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen w-full">

      <BgIcons position="absolute" />

      {/* Header */}
      <header className="relative z-10 text-center px-8 mb-10">
        <div className="flex items-center justify-center gap-4 mb-6">
          <div className="h-px flex-1 max-w-xs" style={{ background: `linear-gradient(90deg, transparent, ${P.gold})` }} />
          <div className="w-3 h-3 rotate-45" style={{ background: P.gold }} />
          <div className="h-px flex-1 max-w-xs" style={{ background: `linear-gradient(90deg, ${P.gold}, transparent)` }} />
        </div>

        <p style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: '11px', color: `${P.secondary}BB`, letterSpacing: '0.3em', textTransform: 'uppercase', marginBottom: 12 }}>
          ◆ CIT NETWORK ◆
        </p>

        <div
          onMouseEnter={() => setTitleHov(true)}
          onMouseLeave={() => setTitleHov(false)}
          style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 0, cursor: 'default' }}
        >
          <h1 style={{
            fontFamily: "'Orbitron', monospace", fontWeight: 900,
            fontSize: 'clamp(1.8rem, 5vw, 3.6rem)', color: P.cream,
            letterSpacing: '0.04em', textShadow: `0 0 40px ${P.gold}55, 0 2px 0 ${P.primary}`,
            lineHeight: 1, marginBottom: 4,
            transform: titleHov ? 'scale(1.06) rotate(-1.5deg)' : 'scale(1) rotate(0deg)',
            transition: 'transform 0.35s cubic-bezier(0.34,1.56,0.64,1)',
            display: 'inline-block',
          }}>
            AMPLIFIED
          </h1>
          <h1 style={{
            fontFamily: "'Orbitron', monospace", fontWeight: 900,
            fontSize: 'clamp(1.8rem, 5vw, 3.6rem)', color: P.gold,
            letterSpacing: '0.04em', textShadow: `0 0 40px ${P.gold}99, 0 2px 0 ${P.primary}`,
            lineHeight: 1, marginBottom: 24,
            transform: titleHov ? 'scale(1.06) rotate(1.5deg)' : 'scale(1) rotate(0deg)',
            transition: 'transform 0.35s cubic-bezier(0.34,1.56,0.64,1)',
            display: 'inline-block',
          }}>
            CIT ORGANIZATIONS
          </h1>
        </div>

        <div className="flex items-center justify-center gap-4">
          <div className="h-px flex-1 max-w-xs" style={{ background: `linear-gradient(90deg, transparent, ${P.gold}66)` }} />
          <span style={{ color: `${P.gold}66`, fontSize: '8px', letterSpacing: '0.2em', fontFamily: 'Share Tech Mono' }}>◆◆◆</span>
          <div className="h-px flex-1 max-w-xs" style={{ background: `linear-gradient(90deg, ${P.gold}66, transparent)` }} />
        </div>
      </header>

      {/* Carousel + scrollbar — NO side fade masks */}
      <section
        className="relative z-10 w-full"
        onMouseEnter={pause}
        onMouseLeave={resume}
        aria-label="CIT Organizations"
      >
        <div ref={trackRef} className="flex items-start will-change-transform"
          style={{ width: 'max-content', paddingTop: 8, paddingBottom: 8 }}>
          {track.map((org, i) => (
            <LogoCard key={`${org.id}-${i}`} org={org} onClick={url => navigate(url)} />
          ))}
        </div>

        {/* Scrollbar */}
        <div className="relative px-16 pt-4 pb-2">
          <input
            ref={scrollbarRef}
            type="range"
            min="0"
            max="100"
            defaultValue="0"
            step="0.1"
            onChange={onScrollbarInput}
            className="org-carousel-scrollbar"
            aria-label="Carousel position"
          />
        </div>
      </section>

      </div>{/* end min-h-screen centered section */}

      {/* CIT About Section */}
      <section style={{
        position: 'relative', zIndex: 10,
        maxWidth: 900, margin: '0 auto',
        padding: '80px 40px 96px',
      }}>
        {/* Section title */}
        <div style={{ textAlign: 'center', marginBottom: 56 }}>
          <p style={{
            fontFamily: "'Share Tech Mono', monospace",
            fontSize: '11px', color: `${P.secondary}BB`,
            letterSpacing: '0.3em', textTransform: 'uppercase', marginBottom: 12,
          }}>
            ◆ CIT ABOUT ◆
          </p>
          <h2 style={{
            fontFamily: "'Orbitron', monospace", fontWeight: 900,
            fontSize: 'clamp(1.4rem, 4vw, 2.4rem)', color: P.cream,
            letterSpacing: '0.06em', textShadow: `0 0 32px ${P.gold}44, 0 2px 0 ${P.primary}`,
            margin: 0,
          }}>
            College of Industrial Technology
          </h2>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 16, marginTop: 20 }}>
            <div style={{ width: 60, height: 1, background: `linear-gradient(90deg, transparent, ${P.gold}66)` }} />
            <span style={{ color: `${P.gold}66`, fontSize: '8px', fontFamily: 'Share Tech Mono', letterSpacing: '0.2em' }}>◆◆◆</span>
            <div style={{ width: 60, height: 1, background: `linear-gradient(90deg, ${P.gold}66, transparent)` }} />
          </div>
        </div>

        {/* History */}
        <div style={{
          background: 'linear-gradient(145deg, #1E2868 0%, #111844 100%)',
          border: `1px solid ${P.border}`,
          borderLeft: `3px solid ${P.gold}`,
          borderRadius: 6,
          boxShadow: '0 8px 24px rgba(0,0,0,0.35)',
          padding: '32px 36px',
          marginBottom: 24,
        }}>
          <p style={{
            fontFamily: "'Orbitron', monospace", fontWeight: 700,
            fontSize: '11px', color: P.gold,
            letterSpacing: '0.2em', textTransform: 'uppercase',
            marginBottom: 20, marginTop: 0,
          }}>
            History
          </p>
          <p style={{
            fontFamily: "'Share Tech Mono', monospace",
            fontSize: '13px', color: P.cream,
            lineHeight: 1.9, margin: 0,
          }}>
            The College of Industrial Technology started in 1952 when the former Bulacan Trade School
            (BTS) offered the Two-Year Special Trade Curriculum for boys in Automotive Mechanics and
            Building Construction. As the school progressed, it continued to offer additional trade
            courses not only for boys, but also for girls as well. Thus, the school became popular in
            the province for its two-year courses and eventually, the Three-Year Technical Course,
            especially during those times when Educational and Engineering Courses were not yet being
            offered. In 1981, the Bulacan College of Arts and Trade (BCAT) offered the Bachelor of
            Science in Industrial Technology (BSIT), which is a four-year course for students who may
            opt to take a Technology Course. However, to keep up with the changing times, the Two-Year
            Technical, Three-Year Technical and Four-Year BSIT Courses were changed to the Bachelor of
            Industrial Technology or BIT ladderized course in 1996. The BIT Course, being a ladderized
            curriculum, requires the student to obtain a certificate after two years of study and should
            they decide to finish the Four-Year BIT program, they will have to pass a qualifying
            examination. With these significant developments in the curriculum, the students became more
            competitive in both regional and national skills competitions. The College continues to
            harness the service of qualified and highly-trained instructors and professors to realize its
            Mission, Vision, Goals and Objectives (VMGOs) in line with the institution's continuing
            search for quality and relevant education.
          </p>
        </div>

        {/* General Objectives */}
        <div style={{
          background: 'linear-gradient(145deg, #1E2868 0%, #111844 100%)',
          border: `1px solid ${P.border}`,
          borderLeft: `3px solid ${P.gold}`,
          borderRadius: 6,
          boxShadow: '0 8px 24px rgba(0,0,0,0.35)',
          padding: '32px 36px',
        }}>
          <p style={{
            fontFamily: "'Orbitron', monospace", fontWeight: 700,
            fontSize: '11px', color: P.gold,
            letterSpacing: '0.2em', textTransform: 'uppercase',
            marginBottom: 20, marginTop: 0,
          }}>
            General Objectives
          </p>
          <p style={{
            fontFamily: "'Share Tech Mono', monospace",
            fontSize: '13px', color: P.cream,
            lineHeight: 1.9, margin: 0,
          }}>
            Provision of technological education, which is nationalist in character that gears towards
            the attainment of quality and excellence through research activities and extension services.
            Generalization and diffusion of technological knowledge in the broad range of discipline
            relevant and responsive to the dynamically changing domestic and international environment.
            Broadening student access to technological education opportunities. Optimization of social,
            institutional and individual returns and benefits derived from the utilization of
            technological education resources.
          </p>
        </div>
      </section>

      <SiteFooter />
    </div>
  )
}
