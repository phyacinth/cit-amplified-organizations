import OrgPage, { OrgPageData } from '@/components/OrgPage'
import logo     from '@/imports/CIT SMTS.jpg'
import award1   from '@/imports/AWARD 1 SMTS.jpg'
import partner1 from '@/imports/PARTNER 1 SMTS.jpg'
import partner2 from '@/imports/PARTNER 2 SMTS.jpg'

const data: OrgPageData = {
  logo,
  fbUrl: 'https://www.facebook.com/profile.php?id=61570113532192',
  name: 'CIT SMTS',
  about: 'SMTS OFFICIAL PAGE | Mechanical Technology',
  accomplishments: [
    {
      img: award1,
      label: 'Award 01',
      description:
        'Mr. Stanlee Salvador — Ambassador 1st Runner-Up. Miss Jessieanne Barlaan — Ambassadress 2nd Runner-Up.',
    },
  ],
  partners: [
    {
      img: partner1,
      name: 'FT Prints',
      description:
        'This is MADE TO ORDER, and an official laboratory merch for Mechanical Technology students. You can wear this during laboratory time, or during Friday. Partner/s: FT Print',
      url: 'https://www.facebook.com/ftprintsph',
    },
    {
      img: partner2,
      name: 'Sitio Tambayan',
      description: 'Bili na kayo guys! Sitio Tamabay is here @BulSU Main campus',
      url: 'https://www.facebook.com/sitiotambayan',
    },
  ],
}

export default function SmtsPage() {
  return <OrgPage data={data} />
}
