import OrgPage, { OrgPageData } from '@/components/OrgPage'
import logo      from '@/imports/cit_spice.jpg'
import award1    from '@/imports/CIT_spice_award_1.jpg'
import award2    from '@/imports/CIT_spice_award_2.jpg'
import award3    from '@/imports/CIT_spice_award_3.jpg'
import stillLife from '@/imports/still_life_photography_logo.jpg'
import ejknows from '@/imports/ej knows logo.jpg'
import pcbulacan from '@/imports/pc_bulacan_logo.jpg'

// Add EJ Knows and PC Bulacan logos here when available:
//   import ejKnows   from '@/imports/Ej_Knows_logo.jpg'
//   import pcBulacan from '@/imports/pc_bulacan_logo.jpg'

const data: OrgPageData = {
  logo,
  fbUrl: 'https://www.facebook.com/BulSUSpice',
  name: 'CIT SPICE',
  about:
    'Society of Proficient and Innovative Computer Enthusiasts (SPICE)',
  accomplishments: [
    {
      img: award1,
      label: 'Award 01',
      description:
        "SPICE Ranked 10th in QUEST 2025: SINAG. Among 104 student organizations, SPICE earned the 10th spot, a remarkable recognition of the organization's continued passion, dedication, and teamwork. This achievement was not simply the result of hard work but of shared experiences — from moments of doubt and burnout to the victories that came from pushing through together.",
    },
    {
      img: award2,
      label: 'Award 02',
      description:
        "Expect the unexpected! We're in! SPICE is now advancing to the next stage of the 21st Search for the Ten Accomplished Youth Organizations.",
    },
    {
      img: award3,
      label: 'Award 03',
      description:
        '𝐑𝐚𝐧𝐤 𝟓 𝐚𝐦𝐨𝐧𝐠 𝟗𝟐 𝐨𝐫𝐠𝐚𝐧𝐢𝐳𝐚𝐭𝐢𝐨𝐧𝐬, 𝐎𝐒𝐎𝐀 𝐈𝐧𝐯𝐨𝐥𝐯𝐞𝐦𝐞𝐧𝐭 𝐀𝐰𝐚𝐫𝐝. The journey from the start up to this day has been very challenging. It was never been an easy road, but it has all been worth it knowing that we have earned another prestigious award. Thank you, Office of the Student Organizations and Activities (OSOA), for awarding our organization the following awards.',
    },
  ],
  partners: [
    {
      img: stillLife,
      name: 'Still Life Photography',
      description: '𝐒𝐭𝐢𝐥𝐥 𝐋𝐢𝐟𝐞, 𝐧𝐨𝐰 𝐛𝐫𝐢𝐧𝐠𝐢𝐧𝐠 𝐒𝐏𝐈𝐂𝐄 𝐭𝐨 𝐞𝐯𝐞𝐫𝐲 𝐟𝐫𝐚𝐦𝐞.',
      url: 'https://www.facebook.com/StillLifePhotographyStudio',
    },
    {
      img: ejknows, // replace null with ejKnows once logo is added
      name: 'Ej Knows',
      description:
        "EJ's expertise in these exciting domains promises to bring you unique perspectives and insights. Follow us to ensure you don't miss any of the fantastic updates and exclusive content EJ will be sharing during the Bulacan Tech Expo.",
      url: 'https://www.facebook.com/ejknowsph',
    },
    {
      img: pcbulacan, // replace null with pcBulacan once logo is added
      name: 'PC Bulacan',
      description:
        'Society of Proficient and Innovative Computer Enthusiasts (SPICE) teams up with PC Bulacan, igniting a partnership that\'s set to redefine the tech landscape.',
      url: 'https://www.facebook.com/pcbulacan',
    },
  ],
}

export default function SpicePage() {
  return <OrgPage data={data} />
}
