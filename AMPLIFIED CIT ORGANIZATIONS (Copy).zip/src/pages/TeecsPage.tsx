import OrgPage, { OrgPageData } from '@/components/OrgPage'
import logo     from '@/imports/CIT TEECS.jpg'
import partner1 from '@/imports/PARTNER 1 TEECS.jpg'
import partner2 from '@/imports/PARTNER 2 CIT TEECS.jpg'

const data: OrgPageData = {
  logo,
  fbUrl: 'https://www.facebook.com/CIT.TEECS',
  name: 'CIT TEECS',
  about:
    'With passion, innovation, and a commitment to excellence, our new Technocrats for Electronics and Electronics Communication Society chapter begins.',
  partners: [
    {
      img: partner1,
      name: 'Nexus Malolos',
      description:
        'In Nexus Malolos, Quality prints. Quick results. Trusted service.',
      url: 'https://www.facebook.com/nexusmalolos',
    },
    {
      img: partner2,
      name: 'Kenneth G Ads & Printing Services',
      description:
        'When it comes to reliable and high-quality printing solutions, Kenneth G Ads & Printing Services is a trusted name.',
      url: 'https://www.facebook.com/search/top?q=kenneth%20g%20ads%20%26%20printing%20services',
    },
  ],
}

export default function TeecsPage() {
  return <OrgPage data={data} />
}
