import { createBrowserRouter } from 'react-router'
import Landing    from './pages/Landing'
import SpicePage  from './pages/SpicePage'
import CreativPage from './pages/CreativPage'
import InfinixPage from './pages/InfinixPage'
import BandPage   from './pages/BandPage'
import FftsPage   from './pages/FftsPage'
import TeecsPage  from './pages/TeecsPage'
import SmtsPage   from './pages/SmtsPage'
import AatsPage   from './pages/AatsPage'
import CadsPage   from './pages/CadsPage'
import FufasPage  from './pages/FufasPage'

export const router = createBrowserRouter([
  { path: '/',       Component: Landing    },
  { path: '/spice',  Component: SpicePage  },
  { path: '/creativ', Component: CreativPage },
  { path: '/infinix', Component: InfinixPage },
  { path: '/band',   Component: BandPage   },
  { path: '/ffts',   Component: FftsPage   },
  { path: '/teecs',  Component: TeecsPage  },
  { path: '/smts',   Component: SmtsPage   },
  { path: '/aats',   Component: AatsPage   },
  { path: '/cads',   Component: CadsPage   },
  { path: '/fufas',  Component: FufasPage  },
])
